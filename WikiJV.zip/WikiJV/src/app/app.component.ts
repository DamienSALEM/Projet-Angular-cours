import { Component, OnInit } from '@angular/core';
// import { Observable } from 'rxjs/Observable';
// import 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  // title = 'WikiJV';

  // listArticles: any[] = [];

  // constructor(private articleService: ArticleService) { }

  // ngOnInit() {
  //   this.listArticles = this.articleService.listArticles;
  // }
  constructor() { }
}
