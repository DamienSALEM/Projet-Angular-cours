import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sno-found',
  templateUrl: './sno-found.component.html',
  styleUrls: ['./sno-found.component.css']
})
export class SnoFoundComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
