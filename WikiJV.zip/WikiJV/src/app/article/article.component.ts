import { Component, Input, OnInit } from '@angular/core';



@Component({
  selector: 'app-article',
  templateUrl: './article.component.html',
  styleUrls: ['./article.component.css']
})
export class ArticleComponent implements OnInit {

  @Input() titleA: string = "";
  @Input() description: string = "";
  @Input() resume: string = "";
  @Input() categorie: string = "";
  @Input() id: number = 1;

  constructor() { }

  ngOnInit(): void {
  }

  OnComment() {
    console.log("comment");
  }
}
